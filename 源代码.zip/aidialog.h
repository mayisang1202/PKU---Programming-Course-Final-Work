#ifndef AIDIALOG_H
#define AIDIALOG_H

#include <QDialog>
#include "global.h"
namespace Ui {
class AiDialog;
}

class AiDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AiDialog(QWidget *parent = nullptr);
    ~AiDialog();
    AccountRecord getRecognizedRecord() const { return recognizedRecord; }
    void setAllowedCategories(const QStringList& categories);
protected:
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dragMoveEvent(QDragMoveEvent *event) override;
    void dropEvent(QDropEvent *event) override;

private slots:
    void on_btn_analyze_clicked();
    void on_btn_confirm_clicked();
    void on_btn_cancel_clicked();
    void on_btn_changeApi_clicked();
    void on_btn_clearApi_clicked();
private:
    Ui::AiDialog *ui;
    QString currentImagePath;
    AccountRecord recognizedRecord;
    QStringList m_allowedCategories;
    QImage m_currentImage;
};

#endif // AIDIALOG_H
