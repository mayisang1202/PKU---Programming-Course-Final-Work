#include "widget.h"
#include "ui_widget.h"
#include "recorddialog.h"
#include "aipredictiondialog.h"
#include "DataManager.h"
#include "global.h"
#include <QStandardItemModel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QDate>
#include <QDialog>
#include <QRadioButton>
#include <QSpinBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QDialogButtonBox>
#include <QFileDialog>
#include <QMessageBox>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    updateTable();
    connect(DataManager::instance(), &DataManager::dataChanged, this, &Widget::updateTable);

    initDateTimeSelectors();
    initChartView();

    updateStatisticsPage();
    connect(DataManager::instance(), &DataManager::dataChanged, this, &Widget::updateStatisticsPage);
    connect(DataManager::instance(), &DataManager::dataChanged, this, &Widget::updateBudgetUI);
    connect(DataManager::instance(), &DataManager::dataChanged, this, &::Widget::on_pushButton_do_search_clicked);
    updateBudgetUI();
    DataManager::instance()->checkAndGeneratePeriodicBills();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::initDateTimeSelectors()
{
    int currentYear = QDate::currentDate().year();
    int currentMonth = QDate::currentDate().month();

    ui->comboBox_year->clear();
    for (int y = currentYear - 5; y <= currentYear + 5; ++y) {
        ui->comboBox_year->addItem(QString("%1年").arg(y), y);
    }

    ui->comboBox_month->clear();
    for (int m = 1; m <= 12; ++m) {
        ui->comboBox_month->addItem(QString("%1月").arg(m), m);
    }

    ui->comboBox_year->setCurrentText(QString("%1年").arg(currentYear));
    ui->comboBox_month->setCurrentIndex(currentMonth - 1);

    connect(ui->comboBox_year, &QComboBox::currentIndexChanged, this, &Widget::updateStatisticsPage);
    connect(ui->comboBox_month, &QComboBox::currentIndexChanged, this, &Widget::updateStatisticsPage);

}

void Widget::initChartView()
{
    QHBoxLayout *chartLayout = qobject_cast<QHBoxLayout*>(ui->chart_view->layout());
    if (!chartLayout) {
        chartLayout = new QHBoxLayout(ui->chart_view);
        ui->chart_view->setLayout(chartLayout);
    }
    chartLayout->setContentsMargins(0, 0, 0, 0);
    chartLayout->setSpacing(15);

    QChartView *chartViewIncome = new QChartView(this);
    chartViewIncome->setObjectName("chartView_income");
    chartViewIncome->setRenderHint(QPainter::Antialiasing);
    chartLayout->addWidget(chartViewIncome);

    QChartView *chartViewExpense = new QChartView(this);
    chartViewExpense->setObjectName("chartView_expense");
    chartViewExpense->setRenderHint(QPainter::Antialiasing);
    chartLayout->addWidget(chartViewExpense);
}

void Widget::updateTable()
{
    QStandardItemModel *model = new QStandardItemModel(this);
    model->setHorizontalHeaderLabels(QStringList() << "日期" << "类型" << "分类" << "金额" << "备注");

    QList<AccountRecord> records = DataManager::instance()->getAllRecords();

    for (int i = 0; i < records.size(); ++i) {
        const AccountRecord& record = records.at(i);

        QStandardItem *itemDate = new QStandardItem(record.date.toString("yyyy-MM-dd"));
        QStandardItem *itemType = new QStandardItem((record.type == INCOME) ? "收入" : "支出");
        QStandardItem *itemCategory = new QStandardItem(record.category);
        QStandardItem *itemAmount = new QStandardItem(QString::number(record.amount, 'f', 2));
        QStandardItem *itemRemark = new QStandardItem(record.remark);

        model->setItem(i, 0, itemDate);
        model->setItem(i, 1, itemType);
        model->setItem(i, 2, itemCategory);
        model->setItem(i, 3, itemAmount);
        model->setItem(i, 4, itemRemark);
    }

    ui->tableView_records->setModel(model);

    ui->tableView_records->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void Widget::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void Widget::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}


void Widget::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void Widget::on_pushButton_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void Widget::on_btn_add_record_clicked()
{
    RecordDialog dialog(this);

    if (dialog.exec() == QDialog::Accepted) {

        AccountRecord newRecord = dialog.getRecordData();
        DataManager::instance()->addRecord(newRecord);

        if (newRecord.isPeriodic) {
            DataManager::instance()->checkAndGeneratePeriodicBills();
        }

        qDebug() << "用户成功添加了一笔账单！";
    }
}


void Widget::on_btn_delete_record_clicked()
{
    int currentRow = ui->tableView_records->currentIndex().row();
    if (currentRow < 0) return;

    QList<AccountRecord> records = DataManager::instance()->getAllRecords();
    int id = records.at(currentRow).id;

    DataManager::instance()->deleteRecord(id);
}


void Widget::on_btn_edit_record_clicked()
{
    int currentRow = ui->tableView_records->currentIndex().row();
    if (currentRow < 0) return;

    QList<AccountRecord> records = DataManager::instance()->getAllRecords();
    AccountRecord selectedRecord = records.at(currentRow);

    RecordDialog dialog(this);

    dialog.setRecordData(selectedRecord);

    if (dialog.exec() == QDialog::Accepted) {

        AccountRecord updatedRecord = dialog.getRecordData();

        DataManager::instance()->deleteRecord(selectedRecord.id);

        DataManager::instance()->addRecord(updatedRecord);

    }
}

void Widget::updateStatisticsPage()
{
    int year = ui->comboBox_year->currentData().toInt();
    int month = ui->comboBox_month->currentData().toInt();

    double totalIncome = DataManager::instance()->getTotalIncome(year, month);
    double totalExpense = DataManager::instance()->getTotalExpense(year, month);
    double netIncome = totalIncome - totalExpense;

    ui->label_total_income->setText(QString("%1年%2月 总收入: ￥%3").arg(year).arg(month).arg(totalIncome, 0, 'f', 2));
    ui->label_total_expense->setText(QString("%1年%2月 总支出: ￥%3").arg(year).arg(month).arg(totalExpense, 0, 'f', 2));
    ui->label_net_income->setText(QString("本月净结余: ￥%1").arg(netIncome, 0, 'f', 2));

    if(netIncome < 0) {
        ui->label_net_income->setStyleSheet("color: red; font-weight: bold;");
    } else {
        ui->label_net_income->setStyleSheet("color: green; font-weight: bold;");
    }

    QDate startDate(year, month, 1);
    QDate endDate = startDate.addMonths(1).addDays(-1);

    QPieSeries *incomeSeries = new QPieSeries();
    QMap<QString, double> incomeStats = DataManager::instance()->getCategoryStats(startDate, endDate, INCOME);
    for (auto it = incomeStats.constBegin(); it != incomeStats.constEnd(); ++it) {
        if (it.value() > 0) {
            incomeSeries->append(QString("%1 (￥%2)").arg(it.key()).arg(it.value(), 0, 'f', 1), it.value());
        }
    }
    QChart *incomeChart = new QChart();
    incomeChart->addSeries(incomeSeries);
    incomeChart->setTitle(QString("%1年%2月 收入来源占比").arg(year).arg(month));
    incomeChart->setAnimationOptions(QChart::SeriesAnimations);

    QChartView *viewIncome = ui->chart_view->findChild<QChartView*>("chartView_income");
    if (viewIncome) {
        viewIncome->setChart(incomeChart);
    }

    QPieSeries *expenseSeries = new QPieSeries();
    QMap<QString, double> expenseStats = DataManager::instance()->getCategoryStats(startDate, endDate, EXPENSE);
    for (auto it = expenseStats.constBegin(); it != expenseStats.constEnd(); ++it) {
        if (it.value() > 0) {
            expenseSeries->append(QString("%1 (￥%2)").arg(it.key()).arg(it.value(), 0, 'f', 1), it.value());
        }
    }
    QChart *expenseChart = new QChart();
    expenseChart->addSeries(expenseSeries);
    expenseChart->setTitle(QString("%1年%2月 支出分类占比").arg(year).arg(month));
    expenseChart->setAnimationOptions(QChart::SeriesAnimations);

    QChartView *viewExpense = ui->chart_view->findChild<QChartView*>("chartView_expense");
    if (viewExpense) {
        viewExpense->setChart(expenseChart);
    }
}

void Widget::on_btn_edit_budget_clicked()
{
    BudgetConfig config = DataManager::instance()->getBudget();
    BudgetDialog dialog(this);
    dialog.setInitialValues(config.monthlyLimit, config.savingsGoal);

    if (dialog.exec() == QDialog::Accepted) {
        double newLimit = dialog.getLimit();
        double newSavings = dialog.getSavings();

        if (DataManager::instance()->setBudget(newLimit, newSavings)) {
            QMessageBox::information(this, "提示", "预算与储蓄目标更新成功！");
            updateBudgetUI();
        } else {
            QMessageBox::critical(this, "错误", "保存失败，请检查数据库。");
        }
    }
}

void Widget::updateBudgetUI()
{
    BudgetConfig config = DataManager::instance()->getBudget();
    double currentExpense = DataManager::instance()->getCurrentMonthExpense();

    int year = QDate::currentDate().year();
    int month = QDate::currentDate().month();
    double currentIncome = DataManager::instance()->getTotalIncome(year, month);
    double netSavings = currentIncome - currentExpense;

    ui->label_budget_info->setText(QString("本月消费限额：￥%1  |  每月储蓄目标：￥%2")
                                       .arg(config.monthlyLimit).arg(config.savingsGoal));

    if (config.monthlyLimit > 0) {
        int expensePercent = static_cast<int>((currentExpense / config.monthlyLimit) * 100);
        ui->progressBar_expense->setMaximum(100);
        ui->progressBar_expense->setValue(qMin(expensePercent, 100));

        if (currentExpense > config.monthlyLimit) {
            ui->progressBar_expense->setStyleSheet("QProgressBar::chunk { background-color: #FF4D4F; }");
            ui->label_budget_status->setText(QString("⚠️ 糟糕，本月已超支！超出额度：￥%1").arg(currentExpense - config.monthlyLimit));
            ui->label_budget_status->setStyleSheet("color: #FF4D4F; font-weight: bold;");
        } else {
            ui->progressBar_expense->setStyleSheet("");
            ui->label_budget_status->setText(QString("本月预算还剩：￥%1，请继续保持。").arg(config.monthlyLimit - currentExpense));
            ui->label_budget_status->setStyleSheet("color: #52C41A;");
        }
    } else {
        ui->progressBar_expense->setValue(0);
        ui->label_budget_status->setText(QString("暂未设置本月消费限额。已支出：￥%1").arg(currentExpense));
        ui->label_budget_status->setStyleSheet("");
    }

    if (config.savingsGoal > 0) {
        ui->progressBar_savings->setMaximum(100);

        if (netSavings <= 0) {
            ui->progressBar_savings->setValue(0);
            ui->label_savings_status->setText(QString("本月尚无净结余（当前赤字：￥%1），继续加油！").arg(-netSavings));
            ui->label_savings_status->setStyleSheet("color: #FAAD14;");
        } else {
            int savingsPercent = static_cast<int>((netSavings / config.savingsGoal) * 100);
            ui->progressBar_savings->setValue(qMin(savingsPercent, 100));

            if (netSavings >= config.savingsGoal) {
                ui->progressBar_savings->setStyleSheet("QProgressBar::chunk { background-color: #52C41A; }");
                ui->label_savings_status->setText(QString("🎉 太棒了！本月储蓄目标已达成（当前结余：￥%1）").arg(netSavings));
                ui->label_savings_status->setStyleSheet("color: #52C41A; font-weight: bold;");
            } else {
                ui->progressBar_savings->setStyleSheet("");
                ui->label_savings_status->setText(QString("已攒：￥%1 / 目标：￥%2（还差 ￥%3）")
                                                      .arg(netSavings).arg(config.savingsGoal).arg(config.savingsGoal - netSavings));
                ui->label_savings_status->setStyleSheet("color: #1890FF;");
            }
        }
    } else {
        ui->progressBar_savings->setValue(0);
        ui->label_savings_status->setText(QString("暂未设置本月储蓄目标。当前实际结余：￥%1").arg(netSavings));
        ui->label_savings_status->setStyleSheet("");
    }
}

void Widget::displaySearchResults(const QList<AccountRecord>& records)
{
    QStandardItemModel *model = new QStandardItemModel(this);
    model->setHorizontalHeaderLabels(QStringList() << "日期" << "类型" << "分类" << "金额" << "备注");

    for (int i = 0; i < records.size(); ++i) {
        const AccountRecord& record = records.at(i);

        QStandardItem *itemDate = new QStandardItem(record.date.toString("yyyy-MM-dd"));
        QStandardItem *itemType = new QStandardItem((record.type == INCOME) ? "收入" : "支出");
        QStandardItem *itemCategory = new QStandardItem(record.category);
        QStandardItem *itemAmount = new QStandardItem(QString::number(record.amount, 'f', 2));
        QStandardItem *itemRemark = new QStandardItem(record.remark);

        model->setItem(i, 0, itemDate);
        model->setItem(i, 1, itemType);
        model->setItem(i, 2, itemCategory);
        model->setItem(i, 3, itemAmount);
        model->setItem(i, 4, itemRemark);
    }

    ui->tableView_search->setModel(model);

    ui->tableView_search->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}
void Widget::on_pushButton_do_search_clicked()
{
    QString keyword = ui->lineEdit_search_keyword->text().trimmed();

    QString category = ui->comboBox_search_category->currentText();
    if (category == "全部") {
        category = "";
    }

    double minAmount = ui->doubleSpinBox_search_min->value();
    double maxAmount = ui->doubleSpinBox_search_max->value();

    if (maxAmount < minAmount) {
        QMessageBox::warning(this, "提示", "最大金额不能小于最小金额！");
        return;
    }

    if (minAmount == 0.0) minAmount = -1;
    if (maxAmount == 999999.0) maxAmount = -1;

    QList<AccountRecord> results = DataManager::instance()->searchRecords(
        minAmount, maxAmount, category, keyword
        );

    displaySearchResults(results);
}


void Widget::on_pushButton_clear_search_clicked()
{
    ui->lineEdit_search_keyword->clear();
    ui->comboBox_search_category->setCurrentIndex(0);
    ui->doubleSpinBox_search_min->setValue(0.00);
    ui->doubleSpinBox_search_max->setValue(999999.00);

    displaySearchResults(QList<AccountRecord>());
}


void Widget::on_btn_export_clicked()
{
    QDialog dialog(this);
    dialog.setWindowTitle("选择导出范围");
    dialog.setFixedSize(500, 260);

    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);

    QRadioButton *radAll = new QRadioButton("保存全部账目", &dialog);
    radAll->setChecked(true);

    QRadioButton *radMonth = new QRadioButton("保存指定月份", &dialog);
    QHBoxLayout *monthLayout = new QHBoxLayout();
    QSpinBox *spinYear = new QSpinBox(&dialog);
    spinYear->setRange(2000, 2099);
    spinYear->setValue(QDate::currentDate().year());
    QSpinBox *spinMonth = new QSpinBox(&dialog);
    spinMonth->setRange(1, 12);
    spinMonth->setValue(QDate::currentDate().month());
    monthLayout->addWidget(new QLabel("年份:", &dialog));
    monthLayout->addWidget(spinYear);
    monthLayout->addWidget(new QLabel("  月份:", &dialog));
    monthLayout->addWidget(spinMonth);
    monthLayout->addStretch();

    QRadioButton *radRange = new QRadioButton("保存指定月份范围", &dialog);
    QHBoxLayout *rangeLayout = new QHBoxLayout();
    QSpinBox *spinStartYear = new QSpinBox(&dialog);
    spinStartYear->setRange(2000, 2099);
    spinStartYear->setValue(QDate::currentDate().year());
    QSpinBox *spinStartMonth = new QSpinBox(&dialog);
    spinStartMonth->setRange(1, 12);
    spinStartMonth->setValue(QDate::currentDate().month());

    QSpinBox *spinEndYear = new QSpinBox(&dialog);
    spinEndYear->setRange(2000, 2099);
    spinEndYear->setValue(QDate::currentDate().year());
    QSpinBox *spinEndMonth = new QSpinBox(&dialog);
    spinEndMonth->setRange(1, 12);
    spinEndMonth->setValue(QDate::currentDate().month());

    rangeLayout->addWidget(spinStartYear);
    rangeLayout->addWidget(new QLabel("年", &dialog));
    rangeLayout->addWidget(spinStartMonth);
    rangeLayout->addWidget(new QLabel("月  至  ", &dialog));
    rangeLayout->addWidget(spinEndYear);
    rangeLayout->addWidget(new QLabel("年", &dialog));
    rangeLayout->addWidget(spinEndMonth);
    rangeLayout->addWidget(new QLabel("月", &dialog));

    spinYear->setEnabled(false);
    spinMonth->setEnabled(false);
    spinStartYear->setEnabled(false);
    spinStartMonth->setEnabled(false);
    spinEndYear->setEnabled(false);
    spinEndMonth->setEnabled(false);

    connect(radAll, &QRadioButton::toggled, [=](bool checked){
        if(checked) {
            spinYear->setEnabled(false); spinMonth->setEnabled(false);
            spinStartYear->setEnabled(false); spinStartMonth->setEnabled(false);
            spinEndYear->setEnabled(false); spinEndMonth->setEnabled(false);
        }
    });
    connect(radMonth, &QRadioButton::toggled, [=](bool checked){
        spinYear->setEnabled(checked);
        spinMonth->setEnabled(checked);
    });
    connect(radRange, &QRadioButton::toggled, [=](bool checked){
        spinStartYear->setEnabled(checked);
        spinStartMonth->setEnabled(checked);
        spinEndYear->setEnabled(checked);
        spinEndMonth->setEnabled(checked);
    });

    mainLayout->addWidget(radAll);
    mainLayout->addWidget(radMonth);
    mainLayout->addLayout(monthLayout);
    mainLayout->addSpacing(10);
    mainLayout->addWidget(radRange);
    mainLayout->addLayout(rangeLayout);
    mainLayout->addSpacing(15);

    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
    connect(buttonBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    mainLayout->addWidget(buttonBox);

    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    QString filePath = QFileDialog::getSaveFileName(
        this,
        "保存导出的CSV账单",
        "我的账单数据.csv",
        "CSV Excel表格文件 (*.csv)"
        );

    if (filePath.isEmpty()) {
        return;
    }

    bool success = false;

    if (radAll->isChecked()) {
        success = DataManager::instance()->exportToCSV(filePath);
    }
    else if (radMonth->isChecked()) {
        int year = spinYear->value();
        int month = spinMonth->value();
        success = DataManager::instance()->exportToCSV(filePath, year, month);
    }
    else if (radRange->isChecked()) {
        int startYear = spinStartYear->value();
        int startMonth = spinStartMonth->value();
        int endYear = spinEndYear->value();
        int endMonth = spinEndMonth->value();

        if (startYear > endYear || (startYear == endYear && startMonth > endMonth)) {
            QMessageBox::warning(this, "提示", "起始月份不能晚于结束月份！");
            return;
        }

        success = DataManager::instance()->exportToCSV(filePath, startYear, startMonth, endYear, endMonth);
    }

    if (success) {
        QMessageBox::information(this, "成功", "账单数据已成功导出！\n路径: " + filePath);
    } else {
        QMessageBox::critical(this, "错误", "数据导出失败！\n请检查该文件是否在 Excel 中打开被占用，或者盘符路径是否正确。");
    }
}

void Widget::on_pushButton_5_clicked()
{
    AiPredictionDialog dialog(this);
    dialog.exec();

}

