#include "aipredictiondialog.h"
#include "ui_aipredictiondialog.h"
#include "DataManager.h"

AiPredictionDialog::AiPredictionDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AiPredictionDialog)
{
    ui->setupUi(this);

    setWindowTitle("AI 财务智脑推演报告");

    connect(ui->pushButton_close, &QPushButton::clicked, this, &QDialog::accept);

    loadAIReport();
}

AiPredictionDialog::~AiPredictionDialog()
{
    delete ui;
}

void AiPredictionDialog::loadAIReport()
{
    ExpensePredictionResult expenseRes = DataManager::instance()->updateAIExpensePrediction();
    SavingsPredictionResult savingsRes = DataManager::instance()->updateAISavingsPrediction();

    QString htmlReport;
    htmlReport += "<h2>🤖 AI 记账助理·深度诊断报告</h2>";
    htmlReport += "<hr>";

    htmlReport += "<h3>📊 本月消费实时推演：</h3>";
    htmlReport += QString("<p>• <b>本月当前已支出：</b> %1 元</p>").arg(expenseRes.currentMonthExpense, 0, 'f', 2);
    htmlReport += QString("<p>• <b>AI预估剩余天数将支出：</b> %1 元</p>").arg(expenseRes.predictedRemaining, 0, 'f', 2);
    htmlReport += QString("<p>• <b>预计本月末最终总支：</b> <font color='%1'><b>%2 元</b></font></p>")
                      .arg(expenseRes.exceedBudget ? "#e74c3c" : "#2ecc71")
                      .arg(expenseRes.totalPrediction, 0, 'f', 2);
    htmlReport += QString("<p>• <b>消费诊断：</b> %1</p>").arg(expenseRes.message);

    htmlReport += "<br><hr>";

    htmlReport += "<h3>🎯 本月储蓄达成轨迹：</h3>";
    htmlReport += QString("<p>• <b>本月当前净结余：</b> %1 元</p>").arg(savingsRes.currentMonthNetSavings, 0, 'f', 2);
    htmlReport += QString("<p>• <b>AI推算剩余日均收益率：</b> %1 元/天</p>").arg(savingsRes.dailyNetSavingsRate, 0, 'f', 2);
    htmlReport += QString("<p>• <b>诊断结论：</b> %1</p>").arg(savingsRes.message);

    ui->textBrowser_report->setHtml(htmlReport);
}