#include "budgetdialog.h"
#include "ui_budgetdialog.h"

BudgetDialog::BudgetDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BudgetDialog)
{
    ui->setupUi(this);
    this->setWindowTitle("修改预算与储蓄目标");

    ui->doubleSpinBox_limit->setRange(0, 999999);
    ui->doubleSpinBox_limit->setPrefix("￥");
    ui->doubleSpinBox_savings->setRange(0, 999999);
    ui->doubleSpinBox_savings->setPrefix("￥");
}

BudgetDialog::~BudgetDialog()
{
    delete ui;
}

void BudgetDialog::setInitialValues(double limit, double savings)
{
    ui->doubleSpinBox_limit->setValue(limit);
    ui->doubleSpinBox_savings->setValue(savings);
}

double BudgetDialog::getLimit() const
{
    return ui->doubleSpinBox_limit->value();
}

double BudgetDialog::getSavings() const
{
    return ui->doubleSpinBox_savings->value();
}

void BudgetDialog::on_btn_ok_clicked()
{
    accept();
}

void BudgetDialog::on_btn_cancel_clicked()
{
    reject();
}