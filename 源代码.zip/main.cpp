#include "widget.h"
#include "DataManager.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QFont font("Microsoft YaHei", 10);
    a.setFont(font);

    a.setStyleSheet(R"(
        QWidget#Widget, QDialog {
            background-color: #F4F6F9;
        }

        QPushButton {
            background-color: #FBD26A;
            color: #663300;
            border-radius: 6px;
            padding: 7px 16px;
            font-size: 14px;
            font-weight: bold;
            border: none;
        }
        QPushButton:hover {
            background-color: #CDA04E;
        }
        QPushButton:pressed {
            background-color: #A47E02;
        }
        QPushButton:disabled {
            background-color: #BDC3C7;
            color: #ECF0F1;
        }

        QLineEdit, QTextEdit {
            border: 1px solid #DCDFE6;
            border-radius: 6px;
            padding: 5px 8px;
            background-color: white;
            color: #000000;
            font-size: 13px;
        }

        QDoubleSpinBox, QDateEdit {
            border: 1px solid #DCDFE6;
            border-radius: 6px;
            padding-top: 5px;
            padding-bottom: 5px;
            padding-left: 8px;
            padding-right: 20px;
            background-color: white;
            color: #000000;
            font-size: 13px;
        }

        QComboBox {
            border: 1px solid #DCDFE6;
            border-radius: 6px;
            padding-top: 5px;
            padding-bottom: 5px;
            padding-left: 8px;
            padding-right: 24px;
            background-color: white;
            color: #000000;
            font-size: 13px;
        }

        QLineEdit:focus, QTextEdit:focus, QDoubleSpinBox:focus, QDateEdit:focus, QComboBox:focus {
            border: 1px solid #007BFF;
        }

        QComboBox::drop-down {
            border: none;
            padding-right: 10px;
        }

        QTableView, QTableWidget {
            background-color: white;
            border: 1px solid #E4E7ED;
            border-radius: 8px;
            gridline-color: #F2F6FC;
        }
        QHeaderView::section {
            background-color: #EBEEF5;
            color: #303133;
            padding: 6px;
            font-weight: bold;
            border: none;
            border-bottom: 1px solid #DCDFE6;
        }

        QGroupBox {
            border: 1px solid #E4E7ED;
            border-radius: 8px;
            margin-top: 12px;
            font-weight: bold;
            color: #303133;
            background-color: white;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    )");

    DataManager::instance()->initDatabase();
    Widget w;
    w.show();
    return QApplication::exec();
}