#ifndef DATAMANAGER_H
#define DATAMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QMap>
#include <QList>
#include <QDate>
#include <QString>
#include <QImage>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <functional>
#include <QMutexLocker>
#include <QSettings>
#include <QSysInfo>
#include <QByteArray>
#include "global.h"

class QSqlQuery;
class DataManager : public QObject
{
    Q_OBJECT

public:
    static DataManager* instance();
    bool initDatabase();
    bool addRecord(const AccountRecord& record);
    bool deleteRecord(int recordId);
    bool updateRecord(const AccountRecord& record);
    QList<AccountRecord> getAllRecords();
    QList<AccountRecord> getPeriodicRecords();
    QList<AccountRecord> searchRecords(double minAmount, double maxAmount,
                                       QString category, QString keyword);
    QList<AccountRecord> searchRecords(double minAmount, double maxAmount,
                                       QString category, QString keyword,
                                       QDate startDate, QDate endDate,
                                       int type = -1);
    double getTotalIncome(int year, int month = 0);
    double getTotalExpense(int year, int month = 0);

    double getTotalIncome(QDate date);
    double getTotalExpense(QDate date);

    QMap<QString, double> getCategoryStats(QDate start, QDate end, RecordType type);

    bool setBudget(double monthlyLimit, double savingsGoal);
    void getBudget(double& monthlyLimit, double& savingsGoal);
    BudgetConfig getBudget();

    double getCurrentMonthExpense();

    void checkAndGeneratePeriodicBills();

    bool exportToCSV(QString filePath);
    bool exportToCSV(QString filePath, int year, int month = 0);
    bool exportToCSV(QString filePath, int startYear, int startMonth,
                     int endYear, int endMonth);

    ExpensePredictionResult updateAIExpensePrediction(int historyMonths = 6, double alpha = 0.5);
    ExpensePredictionResult getAIExpensePrediction();
    SavingsPredictionResult updateAISavingsPrediction(int historyMonths = 6, double alpha = 0.5);
    SavingsPredictionResult getAISavingsPrediction();
    bool isPredictionOverBudget();
    void recognizeReceiptImage(const QString& imagePath);
    using AiCallback = std::function<void(bool success, const AccountRecord& record, const QString& errorMsg)>;
    ApiConfig getApiConfig() const;
    bool setApiConfig(const ApiConfig& config);
    bool hasApiConfig() const;
    void clearApiConfig();
    void recognizeReceiptWithAi(const QString& userPrompt,
                                const QImage& image,
                                const QStringList& allowedCategories,
                                AiCallback callback);
signals:
    void dataChanged();
    void recognitionFinished(const ImageRecognitionResult& result);
private:
    explicit DataManager(QObject* parent = nullptr);
    ~DataManager();

    DataManager(const DataManager&) = delete;
    DataManager& operator=(const DataManager&) = delete;
    bool ensureDatabase();
    void bindRecordForSave(QSqlQuery& query, const AccountRecord& record);
    bool insertRecordWithoutSignal(const AccountRecord& record);
    AccountRecord recordFromQuery(const QSqlQuery& query) const;
    double getTotalByType(int year, int month, RecordType type);
    double getTotalByType(QDate date, RecordType type);
    QDate nextPeriodicDate(const QDate& date, const QString& periodType) const;
    QString csvEscape(const QString& value) const;
    double calculateFixedExpenseForMonth(const QDate& monthStart);
    QList<double> getRecentFlexibleMonthlyExpenses(int historyMonths);
    double calculateOutlierThreshold(const QList<double>& values) const;
    double calculateEWMA(const QList<double>& values, double alpha) const;
    bool saveExpensePrediction(const ExpensePredictionResult& result);
    ExpensePredictionResult predictionFromQuery(const QSqlQuery& query) const;
    double calculateFixedIncomeForMonth(const QDate& monthStart);
    QList<double> getRecentFlexibleMonthlyIncomes(int historyMonths);
    double getCurrentSavingsBalance();
    bool saveSavingsPrediction(const SavingsPredictionResult& result);
    SavingsPredictionResult savingsPredictionFromQuery(const QSqlQuery& query) const;
    QSqlDatabase db;
    QNetworkAccessManager* networkManager = nullptr;
    QByteArray getEncryptionKey() const;
    QString encryptString(const QString& plain) const;
    QString decryptString(const QString& encrypted) const;

    mutable QMutex configMutex;
};

#endif // DATAMANAGER_H
