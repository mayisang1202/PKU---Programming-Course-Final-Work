#ifndef GLOBAL_H
#define GLOBAL_H

#include <QDate>
#include <QString>

enum RecordType {
    INCOME = 0,     // 收入
    EXPENSE = 1     // 支出
};

// 单条账目记录。
struct AccountRecord {
    int id = -1;                         // 数据库主键
    double amount = 0.0;                 // 金额
    RecordType type = EXPENSE;           // 账目类型：收入或支出
    QString category;                    // 分类名称
    QDate date = QDate::currentDate();   // 账目发生日期
    QString remark;                      // 备注内容

    bool isPeriodic = false;             // 周期账单模板
    QString periodType;                  // 周期类型
    QDate nextDate;                      // 下一次自动生成账目的日期
};

// 用户的消费管理配置。
struct BudgetConfig {
    double monthlyLimit = 0.0;           // 每月消费上限
    double savingsGoal = 0.0;            // 每月储蓄目标
};

// 下月消费预测结果。
struct ExpensePredictionResult {
    QDate targetMonth = QDate(QDate::currentDate().year(), QDate::currentDate().month(), 1);
    double currentMonthExpense = 0.0;    // 本月当前已经真实发生的支出
    double predictedRemaining = 0.0;     // 根据历史算出的本月剩余天数预计还要花多少钱
    double totalPrediction = 0.0;        // 最终预估
    double monthlyLimit = 0.0;           // 当前设置的每月消费上限
    bool exceedBudget = false;           // 预测总支出是否超过上限

    int historyMonths = 6;
    double alpha = 0.5;
    double outlierThreshold = 0.0;
    int usedMonthCount = 0;
    int removedOutlierCount = 0;

    QDate updatedAtDate = QDate::currentDate();
    QString message;
};

struct SavingsPredictionResult {
    QDate targetMonth = QDate(QDate::currentDate().year(), QDate::currentDate().month(), 1);
    double currentMonthNetSavings = 0.0; // 本月当前已发生的净储蓄
    double savingsGoal = 0.0;            // 本月设定的储蓄目标
    double predictedIncome = 0.0;        // 本月预测最终总收入
    double predictedExpense = 0.0;       // 本月预测最终总支出
    double dailyNetSavingsRate = 0.0;    // 推演出的本月剩余天数日均净增量
    bool isAchievable = false;           // 本月目标是否可达成

    int historyMonths = 6;               // 参与预测的历史月份数量
    double alpha = 0.5;                  // EWMA 平滑系数
    double incomeOutlierThreshold = 0.0; // 弹性收入异常值阈值
    int usedMonthCount = 0;              // 清洗后实际参与 EWMA 的月份数量
    int removedOutlierCount = 0;         // 被剔除的异常月份数量

    QDate estimatedAchieveDate;          // 预计本月达成的具体日期
    QDate updatedAtDate = QDate::currentDate(); // 最近一次更新预测的日期
    QString message;                     // 文案提示
};

struct ImageRecognitionResult {
    bool success = false;          // 是否识别成功
    double amount = 0.0;           // 识别出的金额
    RecordType type = EXPENSE;     // 账目类型
    QString category;              // 自动匹配的分类
    QDate date = QDate::currentDate(); // 识别出的日期
    QString remark;                // 备注
    QString errorMessage;          // 记录错误信息
};

struct ApiConfig {
    QString apiUrl = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions";
    QString apiKey;
    QString model = "qwen-vl-plus";
};
#endif // GLOBAL_H
