#include "apiconfigdialog.h"
#include "ui_apiconfigdialog.h"
#include "DataManager.h"
#include <QMessageBox>

ApiConfigDialog::ApiConfigDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ApiConfigDialog)
{
    ui->setupUi(this);
    setWindowTitle("配置大模型 API");
    ApiConfig currentConfig = DataManager::instance()->getApiConfig();
    ui->lineEdit_url->setText(currentConfig.apiUrl);
    ui->lineEdit_key->setText(currentConfig.apiKey);
    ui->lineEdit_model->setText(currentConfig.model);
}

ApiConfigDialog::~ApiConfigDialog()
{
    delete ui;
}

void ApiConfigDialog::on_buttonBox_accepted()
{
    QString key = ui->lineEdit_key->text().trimmed();
    if (key.isEmpty()) {
        QMessageBox::warning(this, "警告", "API Key 不能为空！");
        return;
    }

    ApiConfig config;
    config.apiUrl = ui->lineEdit_url->text().trimmed();
    config.apiKey = key;
    config.model = ui->lineEdit_model->text().trimmed();

    DataManager::instance()->setApiConfig(config);

    accept();
}