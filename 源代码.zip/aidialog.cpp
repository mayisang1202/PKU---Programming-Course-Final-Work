#include "aidialog.h"
#include "ui_aidialog.h"
#include "DataManager.h"
#include "global.h"
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QUrl>
#include <QFileInfo>
#include <QPixmap>
#include "apiconfigdialog.h"
#include <QMessageBox>

AiDialog::AiDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AiDialog)
{
    ui->setupUi(this);

    setAcceptDrops(true);
    ui->textEdit_prompt->setAcceptDrops(false);
    ui->textEdit_prompt->setPlaceholderText("可在此输入补充说明（例如：“这是今天请客吃饭，帮我归类”）...");
    ui->label_status->setText("等待图片拖入或输入文字...");
}

AiDialog::~AiDialog()
{
    delete ui;
}

void AiDialog::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasUrls()) {
        event->acceptProposedAction();
    }
}

void AiDialog::dragMoveEvent(QDragMoveEvent *event)
{
    if (event->mimeData()->hasUrls()) {
        event->acceptProposedAction();
    }
}

void AiDialog::dropEvent(QDropEvent *event)
{
    QList<QUrl> urls = event->mimeData()->urls();
    if (!urls.isEmpty()) {
        QUrl url = urls.first();
        QString localPath = url.toLocalFile();

        if (!localPath.isEmpty()) {
            if (m_currentImage.load(localPath)) {
                QFileInfo fileInfo(localPath);
                ui->textEdit_prompt->append(QString("\n[🖼️ 已成功关联图片：%1]").arg(fileInfo.fileName()));

                ui->label_status->setText("✅ 单据图片载入成功！可点击下方按钮开始识别。");
                ui->label_status->setStyleSheet("color: #27ae60; font-weight: bold;");
            } else {
                ui->label_status->setText("❌ 图片文件损坏或格式不支持！");
                ui->label_status->setStyleSheet("color: #e74c3c;");
            }
        }
    }
}

void AiDialog::on_btn_analyze_clicked()
{
    if (!DataManager::instance()->hasApiConfig()) {
        ApiConfigDialog configDlg(this);
        if (configDlg.exec() != QDialog::Accepted) {
            ui->label_status->setText("❌ 未配置 API 密钥，无法进行识别。");
            ui->label_status->setStyleSheet("color: #e74c3c;");
            return;
        }
    }

    ui->label_status->setText("⚡ 正在连线大模型后台识别中，请稍候...");
    ui->label_status->setStyleSheet("color: #3498db; font-weight: bold;");
    ui->btn_confirm->setEnabled(false);
    ui->label_status->setText("⚡ 正在连线大模型后台识别中，请稍候...");
    ui->label_status->setStyleSheet("color: #3498db; font-weight: bold;");
    ui->btn_confirm->setEnabled(false);

    DataManager::instance()->recognizeReceiptWithAi(
        ui->textEdit_prompt->toPlainText(),
        m_currentImage,
        m_allowedCategories,
        [this](bool success, const AccountRecord& record, const QString& errorMsg) {
            if (success) {
                recognizedRecord = record;
                ui->label_status->setText(QString("✅ 识别成功！金额: %1 | 分类: %2")
                                              .arg(record.amount).arg(record.category));
                ui->label_status->setStyleSheet("color: #27ae60; font-weight: bold;");
                ui->btn_confirm->setEnabled(true);
            } else {
                ui->label_status->setText("❌ 识别失败: " + errorMsg);
                ui->label_status->setStyleSheet("color: #e74c3c;");
            }
        }
        );
}

void AiDialog::on_btn_confirm_clicked()
{
    accept();
}

void AiDialog::on_btn_cancel_clicked()
{
    reject();
}

void AiDialog::setAllowedCategories(const QStringList& categories)
{
    m_allowedCategories = categories;
}
void AiDialog::on_btn_changeApi_clicked()
{
    ApiConfigDialog configDlg(this);
    if (configDlg.exec() == QDialog::Accepted) {
        ui->label_status->setText("✅ API 配置更换成功！已重新加载新密钥。");
        ui->label_status->setStyleSheet("color: #27ae60; font-weight: bold;");
    }
}

void AiDialog::on_btn_clearApi_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认清除",
                                  "确定要清除本地保存的 AI 密钥和配置吗？\n清除后将无法进行智能记账。",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        DataManager::instance()->clearApiConfig();

        ui->label_status->setText("💡 本地 API 密钥已清空。下次识别将重新提示输入。");
        ui->label_status->setStyleSheet("color: #e67e22; font-weight: bold;");
    }
}
