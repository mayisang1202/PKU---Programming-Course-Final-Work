QT += widgets sql charts
QT += network

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    aidialog.cpp \
    aipredictiondialog.cpp \
    apiconfigdialog.cpp \
    budgetdialog.cpp \
    datamanager.cpp \
    main.cpp \
    recorddialog.cpp \
    widget.cpp

HEADERS += \
    aidialog.h \
    aipredictiondialog.h \
    apiconfigdialog.h \
    budgetdialog.h \
    datamanager.h \
    global.h \
    recorddialog.h \
    widget.h

FORMS += \
    aidialog.ui \
    aipredictiondialog.ui \
    apiconfigdialog.ui \
    budgetdialog.ui \
    recorddialog.ui \
    widget.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
