#include "recorddialog.h"
#include "ui_recorddialog.h"
#include "DataManager.h"
#include "aidialog.h"
#include "global.h"
#include <QInputDialog>

RecordDialog::RecordDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::RecordDialog)
{
    ui->setupUi(this);

    initTypeAndCategorySelectors();

    ui->dateEdit_date->setDate(QDate::currentDate());


}

RecordDialog::~RecordDialog()
{
    delete ui;
}

void RecordDialog::on_btn_ok_clicked()
{
    if (ui->checkBox_isPeriodic->isChecked()) {
        QStringList periods;
        periods << "日度账单 (每天自动生成)"
                << "月度账单 (每月自动生成)"
                << "年度账单 (每年自动生成)";

        bool ok = false;
        QString selected = QInputDialog::getItem(
            this,
            "选择周期类型",
            "请选择该周期账单的循环频率：",
            periods,
            1,
            false,
            &ok
            );

        if (ok && !selected.isEmpty()) {
            if (selected.startsWith("日度")) {
                m_periodType = "day";
            } else if (selected.startsWith("月度")) {
                m_periodType = "month";
            } else if (selected.startsWith("年度")) {
                m_periodType = "year";
            }

            accept();
        } else {
            return;
        }
    } else {
        m_periodType = "";
        accept();
    }
}


void RecordDialog::on_btn_cancel_clicked()
{
    reject();
}

void RecordDialog::setRecordData(const AccountRecord& record)
{
    ui->doubleSpinBox_amount->setValue(record.amount);
    ui->comboBox_type->setCurrentIndex((record.type == INCOME) ? 0 : 1);
    ui->comboBox_category->setCurrentText(record.category);
    ui->dateEdit_date->setDate(record.date);
    ui->lineEdit_remark->setText(record.remark);

    ui->checkBox_isPeriodic->setChecked(record.isPeriodic);
    m_periodType = record.periodType;
}

AccountRecord RecordDialog::getRecordData() const
{
    AccountRecord record;
    record.amount = ui->doubleSpinBox_amount->value();
    record.type = (ui->comboBox_type->currentIndex() == 0) ? INCOME : EXPENSE;
    record.category = ui->comboBox_category->currentText();
    record.date = ui->dateEdit_date->date();
    record.remark = ui->lineEdit_remark->text();

    record.isPeriodic = ui->checkBox_isPeriodic->isChecked();
    if (record.isPeriodic) {
        record.periodType = m_periodType;
        record.nextDate = record.date;
    } else {
        record.periodType = "";
    }

    return record;
}

void RecordDialog::initTypeAndCategorySelectors()
{
    ui->comboBox_type->clear();
    ui->comboBox_type->addItems(QStringList() << "收入" << "支出");

    connect(ui->comboBox_type, &QComboBox::currentIndexChanged, this, [this](int index){
        ui->comboBox_category->clear();

        if (index == 0) {
            ui->comboBox_category->addItems(QStringList() << "基本工资" << "奖金" << "补贴" << "投资" << "其他");
        } else {
            ui->comboBox_category->addItems(QStringList() << "餐饮" << "购物" << "娱乐" << "交通" << "其他");
        }
    });

    ui->comboBox_type->setCurrentIndex(1);
}

void RecordDialog::on_AIidentify_clicked()
{
    AiDialog aiDlg(this);

    QStringList allCategories;
    allCategories << "基本工资" << "奖金" << "补贴" << "投资"
                  << "餐饮" << "购物" << "娱乐" << "交通" << "其他";

    aiDlg.setAllowedCategories(allCategories);

    if (aiDlg.exec() == QDialog::Accepted) {
        AccountRecord record = aiDlg.getRecognizedRecord();

        ui->doubleSpinBox_amount->setValue(record.amount);
        ui->lineEdit_remark->setText(record.remark);
        ui->dateEdit_date->setDate(record.date);
        ui->comboBox_type->setCurrentIndex(record.type == INCOME ? 0 : 1);

        int catIndex = ui->comboBox_category->findText(record.category);
        if (catIndex != -1) {
            ui->comboBox_category->setCurrentIndex(catIndex);
        } else {
            ui->comboBox_category->addItem(record.category);
            ui->comboBox_category->setCurrentIndex(ui->comboBox_category->count() - 1);
        }
    }
}
