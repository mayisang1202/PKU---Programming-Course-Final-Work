#ifndef RECORDDIALOG_H
#define RECORDDIALOG_H

#include <QDialog>
#include "global.h"

namespace Ui {
class RecordDialog;
}

class RecordDialog : public QDialog
{
    Q_OBJECT

public:
    explicit RecordDialog(QWidget *parent = nullptr);
    ~RecordDialog();
    void setRecordData(const AccountRecord& record);
    AccountRecord getRecordData() const;

private slots:
    void on_btn_ok_clicked();
    void on_AIidentify_clicked();
    void on_btn_cancel_clicked();

private:
    Ui::RecordDialog *ui;

    void initTypeAndCategorySelectors();

    QString m_periodType;
};

#endif // RECORDDIALOG_H
