#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QPieSeries>
#include "budgetdialog.h"
#include "global.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget() override;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_btn_add_record_clicked();

    void updateTable();

    void on_btn_delete_record_clicked();

    void on_btn_edit_record_clicked();

    void updateStatisticsPage();

    void on_btn_edit_budget_clicked();

    void updateBudgetUI();



    void on_pushButton_do_search_clicked();

    void on_pushButton_clear_search_clicked();

    void on_btn_export_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Widget *ui;

    void initDateTimeSelectors();

    void initChartView();

    void displaySearchResults(const QList<AccountRecord>& records);

};
#endif // WIDGET_H
