#ifndef BUDGETDIALOG_H
#define BUDGETDIALOG_H

#include <QDialog>

namespace Ui {
class BudgetDialog;
}

class BudgetDialog : public QDialog
{
    Q_OBJECT

public:
    explicit BudgetDialog(QWidget *parent = nullptr);
    ~BudgetDialog();

    void setInitialValues(double limit, double savings);
    double getLimit() const;
    double getSavings() const;

private slots:
    void on_btn_ok_clicked();
    void on_btn_cancel_clicked();

private:
    Ui::BudgetDialog *ui;
};

#endif // BUDGETDIALOG_H