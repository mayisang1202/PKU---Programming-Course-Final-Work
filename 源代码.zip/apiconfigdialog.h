#ifndef APICONFIGDIALOG_H
#define APICONFIGDIALOG_H

#include <QDialog>
#include "global.h"

namespace Ui {
class ApiConfigDialog;
}

class ApiConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ApiConfigDialog(QWidget *parent = nullptr);
    ~ApiConfigDialog();

private slots:
    void on_buttonBox_accepted();

private:
    Ui::ApiConfigDialog *ui;
};

#endif // APICONFIGDIALOG_H