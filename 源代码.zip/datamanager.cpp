#include "DataManager.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QImage>
#include <QIODevice>
#include <QSqlQuery>
#include <QTextStream>
#include <QVariant>
#include <QtGlobal>
#include <QBuffer>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QImageReader>
#include <algorithm>
#include <cmath>
#include <QSettings>
#include <QSysInfo>
#include <QCryptographicHash>
#include <QDataStream>
#include <QByteArray>
// 返回 DataManager 的唯一实例
DataManager* DataManager::instance()
{
    static DataManager manager;
    return &manager;
}

DataManager::DataManager(QObject* parent)
    : QObject(parent)
{
    networkManager = new QNetworkAccessManager(this);
}

DataManager::~DataManager()
{
    if (db.isOpen()) {
        db.close();
    }
}

// 初始化 SQLite 数据库
bool DataManager::initDatabase()
{
    if (!db.isValid()) {
        db = QSqlDatabase::addDatabase("QSQLITE", "account_book_connection");
    }

    if (!db.isOpen()) {
        QString basePath = QCoreApplication::applicationDirPath();
        if (basePath.isEmpty() || basePath == ".") {
            basePath = QDir::currentPath();
        }

        QDir().mkpath(basePath);
        db.setDatabaseName(basePath + "/account_book.db");
        if (!db.open()) {
            return false;
        }
    }

    QSqlQuery query(db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS records ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "amount REAL NOT NULL,"
                    "type INTEGER NOT NULL,"
                    "category TEXT,"
                    "date TEXT NOT NULL,"
                    "remark TEXT,"
                    "is_periodic INTEGER NOT NULL DEFAULT 0,"
                    "period_type TEXT,"
                    "next_date TEXT)")) {
        return false;
    }

    if (!query.exec("CREATE TABLE IF NOT EXISTS budget_config ("
                    "id INTEGER PRIMARY KEY CHECK(id = 1),"
                    "monthly_limit REAL NOT NULL DEFAULT 0,"
                    "savings_goal REAL NOT NULL DEFAULT 0)")) {
        return false;
    }

    if (!query.exec("INSERT OR IGNORE INTO budget_config "
                    "(id, monthly_limit, savings_goal) VALUES (1, 0, 0)")) {
        return false;
    }

    query.exec("DROP TABLE IF EXISTS ai_prediction_cache");
    query.exec("DROP TABLE IF EXISTS ai_savings_prediction_cache");

    if (!query.exec("CREATE TABLE ai_prediction_cache ("
                    "id INTEGER PRIMARY KEY CHECK(id = 1),"
                    "target_month TEXT,"
                    "current_month_expense REAL NOT NULL DEFAULT 0,"
                    "predicted_remaining REAL NOT NULL DEFAULT 0,"
                    "total_prediction REAL NOT NULL DEFAULT 0,"
                    "monthly_limit REAL NOT NULL DEFAULT 0,"
                    "exceed_budget INTEGER NOT NULL DEFAULT 0,"
                    "history_months INTEGER NOT NULL DEFAULT 6,"
                    "alpha REAL NOT NULL DEFAULT 0.5,"
                    "outlier_threshold REAL NOT NULL DEFAULT 0,"
                    "used_month_count INTEGER NOT NULL DEFAULT 0,"
                    "removed_outlier_count INTEGER NOT NULL DEFAULT 0,"
                    "updated_at TEXT,"
                    "message TEXT)")) {
        return false;
    }

    if (!query.exec("CREATE TABLE ai_savings_prediction_cache ("
                    "id INTEGER PRIMARY KEY CHECK(id = 1),"
                    "target_month TEXT,"
                    "current_month_net_savings REAL NOT NULL DEFAULT 0,"
                    "savings_goal REAL NOT NULL DEFAULT 0,"
                    "predicted_income REAL NOT NULL DEFAULT 0,"
                    "predicted_expense REAL NOT NULL DEFAULT 0,"
                    "daily_net_savings_rate REAL NOT NULL DEFAULT 0,"
                    "is_achievable INTEGER NOT NULL DEFAULT 0,"
                    "estimated_achieve_date TEXT,"
                    "history_months INTEGER NOT NULL DEFAULT 6,"
                    "alpha REAL NOT NULL DEFAULT 0.5,"
                    "income_outlier_threshold REAL NOT NULL DEFAULT 0,"
                    "used_month_count INTEGER NOT NULL DEFAULT 0,"
                    "removed_outlier_count INTEGER NOT NULL DEFAULT 0,"
                    "updated_at TEXT,"
                    "message TEXT)")) {
        return false;
    }

    if (!query.exec("INSERT OR IGNORE INTO ai_savings_prediction_cache "
                    "(id, target_month, updated_at, message) "
                    "VALUES (1, '', '', '')")) {
        return false;
    }

    return query.exec("INSERT OR IGNORE INTO ai_prediction_cache "
                      "(id, target_month, updated_at, message) "
                      "VALUES (1, '', '', '')");
}

// 添加一条账目或周期账单模板
bool DataManager::addRecord(const AccountRecord& record)
{
    if (!ensureDatabase()) {
        return false;
    }

    QSqlQuery query(db);
    query.prepare("INSERT INTO records "
                  "(amount, type, category, date, remark, is_periodic, period_type, next_date) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    bindRecordForSave(query, record);

    const bool ok = query.exec();
    if (ok) {
        updateAIExpensePrediction();
        updateAISavingsPrediction();
        emit dataChanged();
    }
    return ok;
}

// 根据主键删除一条记录
bool DataManager::deleteRecord(int recordId)
{
    if (!ensureDatabase()) {
        return false;
    }

    QSqlQuery query(db);
    query.prepare("DELETE FROM records WHERE id = ?");
    query.addBindValue(recordId);

    const bool ok = query.exec();
    if (ok) {
        updateAIExpensePrediction();
        updateAISavingsPrediction();
        emit dataChanged();
    }
    return ok;
}

// 修改一条已有记录
bool DataManager::updateRecord(const AccountRecord& record)
{
    if (!ensureDatabase() || record.id < 0) {
        return false;
    }

    QSqlQuery query(db);
    query.prepare("UPDATE records SET "
                  "amount = ?, type = ?, category = ?, date = ?, remark = ?, "
                  "is_periodic = ?, period_type = ?, next_date = ? "
                  "WHERE id = ?");
    bindRecordForSave(query, record);
    query.addBindValue(record.id);

    const bool ok = query.exec();
    if (ok) {
        updateAIExpensePrediction();
        updateAISavingsPrediction();
        emit dataChanged();
    }
    return ok;
}

// 获取所有普通账目
QList<AccountRecord> DataManager::getAllRecords()
{
    QList<AccountRecord> result;
    if (!ensureDatabase()) {
        return result;
    }

    QSqlQuery query(db);
    query.prepare("SELECT id, amount, type, category, date, remark, "
                  "is_periodic, period_type, next_date "
                  "FROM records WHERE is_periodic = 0 "
                  "ORDER BY date DESC, id DESC");
    if (!query.exec()) {
        return result;
    }

    while (query.next()) {
        result.append(recordFromQuery(query));
    }
    return result;
}

// 获取所有周期性账单模板
QList<AccountRecord> DataManager::getPeriodicRecords()
{
    QList<AccountRecord> result;
    if (!ensureDatabase()) {
        return result;
    }

    QSqlQuery query(db);
    query.prepare("SELECT id, amount, type, category, date, remark, "
                  "is_periodic, period_type, next_date "
                  "FROM records WHERE is_periodic = 1 "
                  "ORDER BY next_date ASC, id ASC");
    if (!query.exec()) {
        return result;
    }

    while (query.next()) {
        result.append(recordFromQuery(query));
    }
    return result;
}

QList<AccountRecord> DataManager::searchRecords(double minAmount, double maxAmount,
                                                 QString category, QString keyword)
{
    return searchRecords(minAmount, maxAmount, category, keyword, QDate(), QDate(), -1);
}

QList<AccountRecord> DataManager::searchRecords(double minAmount, double maxAmount,
                                                 QString category, QString keyword,
                                                 QDate startDate, QDate endDate,
                                                 int type)
{
    QList<AccountRecord> result;
    if (!ensureDatabase()) {
        return result;
    }

    QString sql = "SELECT id, amount, type, category, date, remark, "
                  "is_periodic, period_type, next_date "
                  "FROM records WHERE is_periodic = 0";
    QList<QVariant> values;
    if (minAmount >= 0) {
        sql += " AND amount >= ?";
        values.append(minAmount);
    }
    if (maxAmount >= 0) {
        sql += " AND amount <= ?";
        values.append(maxAmount);
    }
    if (!category.trimmed().isEmpty()) {
        sql += " AND category = ?";
        values.append(category.trimmed());
    }
    if (!keyword.trimmed().isEmpty()) {
        sql += " AND remark LIKE ?";
        values.append("%" + keyword.trimmed() + "%");
    }
    if (startDate.isValid()) {
        sql += " AND date >= ?";
        values.append(startDate.toString(Qt::ISODate));
    }
    if (endDate.isValid()) {
        sql += " AND date <= ?";
        values.append(endDate.toString(Qt::ISODate));
    }
    if (type == INCOME || type == EXPENSE) {
        sql += " AND type = ?";
        values.append(type);
    }
    sql += " ORDER BY date DESC, id DESC";

    QSqlQuery query(db);
    query.prepare(sql);
    for (const QVariant& value : values) {
        query.addBindValue(value);
    }
    if (!query.exec()) {
        return result;
    }

    while (query.next()) {
        result.append(recordFromQuery(query));
    }
    return result;
}

// 统计某年或某月的收入总额
double DataManager::getTotalIncome(int year, int month)
{
    return getTotalByType(year, month, INCOME);
}

// 统计某年或某月的支出总额
double DataManager::getTotalExpense(int year, int month)
{
    return getTotalByType(year, month, EXPENSE);
}

// 统计某一天的收入总额
double DataManager::getTotalIncome(QDate date)
{
    return getTotalByType(date, INCOME);
}

// 统计某一天的支出总额
double DataManager::getTotalExpense(QDate date)
{
    return getTotalByType(date, EXPENSE);
}

// 按分类汇总指定日期范围内的收入或支出
QMap<QString, double> DataManager::getCategoryStats(QDate start, QDate end, RecordType type)
{
    QMap<QString, double> result;
    if (!ensureDatabase() || !start.isValid() || !end.isValid()) {
        return result;
    }

    QSqlQuery query(db);
    query.prepare("SELECT category, SUM(amount) FROM records "
                  "WHERE is_periodic = 0 AND type = ? AND date >= ? AND date <= ? "
                  "GROUP BY category ORDER BY SUM(amount) DESC");
    query.addBindValue(static_cast<int>(type));
    query.addBindValue(start.toString(Qt::ISODate));
    query.addBindValue(end.toString(Qt::ISODate));

    if (!query.exec()) {
        return result;
    }

    while (query.next()) {
        result.insert(query.value(0).toString(), query.value(1).toDouble());
    }
    return result;
}

// 保存每月消费上限和储蓄目标
bool DataManager::setBudget(double monthlyLimit, double savingsGoal)
{
    if (!ensureDatabase()) {
        return false;
    }

    QSqlQuery query(db);
    query.prepare("UPDATE budget_config SET monthly_limit = ?, savings_goal = ? WHERE id = 1");
    query.addBindValue(monthlyLimit);
    query.addBindValue(savingsGoal);
    const bool ok = query.exec();
    if (ok) {
        updateAIExpensePrediction();
        updateAISavingsPrediction();

        emit dataChanged();
    }

    return ok;
}

// 通过引用参数返回预算配置
void DataManager::getBudget(double& monthlyLimit, double& savingsGoal)
{
    monthlyLimit = 0.0;
    savingsGoal = 0.0;
    if (!ensureDatabase()) {
        return;
    }

    QSqlQuery query(db);
    if (query.exec("SELECT monthly_limit, savings_goal FROM budget_config WHERE id = 1")
            && query.next()) {
        monthlyLimit = query.value(0).toDouble();
        savingsGoal = query.value(1).toDouble();
    }
}

// 返回结构体形式的预算配置
BudgetConfig DataManager::getBudget()
{
    BudgetConfig config;
    getBudget(config.monthlyLimit, config.savingsGoal);
    return config;
}

// 获取当前月份已经产生的普通支出总额
double DataManager::getCurrentMonthExpense()
{
    const QDate today = QDate::currentDate();
    return getTotalExpense(today.year(), today.month());
}

// 自动生成周期性账单
void DataManager::checkAndGeneratePeriodicBills()
{
    if (!ensureDatabase()) {
        return;
    }

    const QList<AccountRecord> templates = getPeriodicRecords();
    const QDate today = QDate::currentDate();
    bool changed = false;

    for (AccountRecord item : templates) {
        QDate dueDate = item.nextDate.isValid() ? item.nextDate : item.date;
        if (!dueDate.isValid() || item.periodType.trimmed().isEmpty()) {
            continue;
        }
        while (dueDate <= today) {
            AccountRecord generated = item;
            generated.id = -1;
            generated.isPeriodic = false;
            generated.periodType.clear();
            generated.nextDate = QDate();
            generated.date = dueDate;
            if (!insertRecordWithoutSignal(generated)) {
                break;
            }
            dueDate = nextPeriodicDate(dueDate, item.periodType);
            changed = true;
        }

        if (dueDate != item.nextDate) {
            QSqlQuery update(db);
            update.prepare("UPDATE records SET next_date = ? WHERE id = ?");
            update.addBindValue(dueDate.toString(Qt::ISODate));
            update.addBindValue(item.id);
            update.exec();
        }
    }

    if (changed) {
        emit dataChanged();
    }
}

// 导出普通账目为 CSV
bool DataManager::exportToCSV(QString filePath)
{
    if (!ensureDatabase()) {
        return false;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream out(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
#endif
    out.setGenerateByteOrderMark(true);
    out << "id,type,amount,category,date,remark\n";

    const QList<AccountRecord> records = getAllRecords();
    for (const AccountRecord& record : records) {
        out << record.id << ','
            << (record.type == INCOME ? "income" : "expense") << ','
            << record.amount << ','
            << csvEscape(record.category) << ','
            << record.date.toString(Qt::ISODate) << ','
            << csvEscape(record.remark) << '\n';
    }

    return true;
}

// 按指定年份或月份导出普通账目为 CSV
bool DataManager::exportToCSV(QString filePath, int year, int month)
{
    if (month < 0 || month > 12) {
        return false;
    }

    if (month == 0) {
        return exportToCSV(filePath, year, 1, year, 12);
    }

    return exportToCSV(filePath, year, month, year, month);
}

// 按指定月份范围导出普通账目为 CSV
bool DataManager::exportToCSV(QString filePath, int startYear, int startMonth,
                              int endYear, int endMonth)
{
    if (!ensureDatabase()) {
        return false;
    }

    const QDate start(startYear, startMonth, 1);
    const QDate endMonthStart(endYear, endMonth, 1);
    if (!start.isValid() || !endMonthStart.isValid() || start > endMonthStart) {
        return false;
    }

    const QDate end = endMonthStart.addMonths(1).addDays(-1);

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream out(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
#endif
    out.setGenerateByteOrderMark(true);
    out << "id,type,amount,category,date,remark\n";

    QSqlQuery query(db);
    query.prepare("SELECT id, amount, type, category, date, remark, "
                  "is_periodic, period_type, next_date "
                  "FROM records "
                  "WHERE is_periodic = 0 AND date >= ? AND date <= ? "
                  "ORDER BY date DESC, id DESC");
    query.addBindValue(start.toString(Qt::ISODate));
    query.addBindValue(end.toString(Qt::ISODate));

    if (!query.exec()) {
        return false;
    }

    while (query.next()) {
        const AccountRecord record = recordFromQuery(query);
        out << record.id << ','
            << (record.type == INCOME ? "income" : "expense") << ','
            << record.amount << ','
            << csvEscape(record.category) << ','
            << record.date.toString(Qt::ISODate) << ','
            << csvEscape(record.remark) << '\n';
    }

    return true;
}

// 更新下个月 AI 消费预测
ExpensePredictionResult DataManager::updateAIExpensePrediction(int historyMonths, double alpha)
{
    ExpensePredictionResult result;
    if (!ensureDatabase()) return result;

    const QDate today = QDate::currentDate();
    result.targetMonth = QDate(today.year(), today.month(), 1);
    result.historyMonths = historyMonths;
    result.alpha = alpha;
    result.currentMonthExpense = getTotalExpense(today.year(), today.month());

    double fixedExpense = calculateFixedExpenseForMonth(result.targetMonth);
    const QList<double> rawFlexibleValues = getRecentFlexibleMonthlyExpenses(historyMonths);
    result.outlierThreshold = calculateOutlierThreshold(rawFlexibleValues);
    QList<double> cleanedValues;
    for (double value : rawFlexibleValues) {
        if (result.outlierThreshold <= 0.0 || value <= result.outlierThreshold) cleanedValues.append(value);
        else result.removedOutlierCount++;
    }
    result.usedMonthCount = cleanedValues.size();

    double historicalExpectedMonthlyExpense = fixedExpense + calculateEWMA(cleanedValues, alpha);

    int daysInMonth = today.daysInMonth();
    int remainingDays = daysInMonth - today.day();

    result.predictedRemaining = (historicalExpectedMonthlyExpense / daysInMonth) * remainingDays;
    result.totalPrediction = result.currentMonthExpense + result.predictedRemaining;

    double monthlyLimit = 0.0, sg = 0.0;
    getBudget(monthlyLimit, sg);
    result.monthlyLimit = monthlyLimit;
    result.exceedBudget = (monthlyLimit > 0.0 && result.totalPrediction > monthlyLimit);
    result.updatedAtDate = today;

    double gap = monthlyLimit - result.totalPrediction;
    if (result.exceedBudget) {
        result.message = QString("危险！按当前节律，本月末预计将超支 %1 元。").arg(-gap, 0, 'f', 2);
    } else {
        result.message = QString("良好。预计本月末将在预算内，且结余安全缓冲金 %1 元。").arg(gap, 0, 'f', 2);
    }

    saveExpensePrediction(result);
    return result;
}

ExpensePredictionResult DataManager::getAIExpensePrediction()
{
    ExpensePredictionResult result;
    if (!ensureDatabase()) return result;
    QSqlQuery query(db);
    if (query.exec("SELECT target_month, current_month_expense, predicted_remaining, total_prediction, "
                   "monthly_limit, exceed_budget, history_months, alpha, outlier_threshold, "
                   "used_month_count, removed_outlier_count, updated_at, message "
                   "FROM ai_prediction_cache WHERE id = 1") && query.next()) {
        result = predictionFromQuery(query);
        if (result.targetMonth.isValid()) return result;
    }
    return updateAIExpensePrediction();
}

bool DataManager::isPredictionOverBudget()
{
    return getAIExpensePrediction().exceedBudget;
}

// 确保数据库已经打开
bool DataManager::ensureDatabase()
{
    return db.isOpen() || initDatabase();
}

void DataManager::bindRecordForSave(QSqlQuery& query, const AccountRecord& record)
{
    query.addBindValue(record.amount);
    query.addBindValue(static_cast<int>(record.type));
    query.addBindValue(record.category);
    query.addBindValue(record.date.toString(Qt::ISODate));
    query.addBindValue(record.remark);
    query.addBindValue(record.isPeriodic ? 1 : 0);
    query.addBindValue(record.periodType);

    const QDate next = record.nextDate.isValid() ? record.nextDate : record.date;
    query.addBindValue(record.isPeriodic ? QVariant(next.toString(Qt::ISODate)) : QVariant());
}

bool DataManager::insertRecordWithoutSignal(const AccountRecord& record)
{
    QSqlQuery query(db);
    query.prepare("INSERT INTO records "
                  "(amount, type, category, date, remark, is_periodic, period_type, next_date) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    bindRecordForSave(query, record);
    return query.exec();
}

// 把 SQL 查询结果的当前行转换成 AccountRecord
AccountRecord DataManager::recordFromQuery(const QSqlQuery& query) const
{
    AccountRecord record;
    record.id = query.value(0).toInt();
    record.amount = query.value(1).toDouble();
    record.type = query.value(2).toInt() == INCOME ? INCOME : EXPENSE;
    record.category = query.value(3).toString();
    record.date = QDate::fromString(query.value(4).toString(), Qt::ISODate);
    record.remark = query.value(5).toString();
    record.isPeriodic = query.value(6).toInt() != 0;
    record.periodType = query.value(7).toString();
    record.nextDate = QDate::fromString(query.value(8).toString(), Qt::ISODate);
    return record;
}

// 按年份或月份统计指定类型的总金额
double DataManager::getTotalByType(int year, int month, RecordType type)
{
    if (!ensureDatabase()) {
        return 0.0;
    }

    const QDate start = month > 0 ? QDate(year, month, 1) : QDate(year, 1, 1);
    const QDate end = month > 0 ? start.addMonths(1).addDays(-1) : QDate(year, 12, 31);
    if (!start.isValid() || !end.isValid()) {
        return 0.0;
    }

    QSqlQuery query(db);
    query.prepare("SELECT COALESCE(SUM(amount), 0) FROM records "
                  "WHERE is_periodic = 0 AND type = ? AND date >= ? AND date <= ?");
    query.addBindValue(static_cast<int>(type));
    query.addBindValue(start.toString(Qt::ISODate));
    query.addBindValue(end.toString(Qt::ISODate));

    if (query.exec() && query.next()) {
        return query.value(0).toDouble();
    }
    return 0.0;
}

// 按单日统计指定类型的总金额
double DataManager::getTotalByType(QDate date, RecordType type)
{
    if (!ensureDatabase() || !date.isValid()) {
        return 0.0;
    }

    QSqlQuery query(db);
    query.prepare("SELECT COALESCE(SUM(amount), 0) FROM records "
                  "WHERE is_periodic = 0 AND type = ? AND date = ?");
    query.addBindValue(static_cast<int>(type));
    query.addBindValue(date.toString(Qt::ISODate));

    if (query.exec() && query.next()) {
        return query.value(0).toDouble();
    }
    return 0.0;
}

// 根据周期类型计算下一次生成日期
QDate DataManager::nextPeriodicDate(const QDate& date, const QString& periodType) const
{
    const QString period = periodType.trimmed().toLower();
    if (period == "day" || period == "daily") {
        return date.addDays(1);
    }
    if (period == "year" || period == "yearly") {
        return date.addYears(1);
    }
    return date.addMonths(1);
}

// 计算指定月份中确定会发生的固定支出
double DataManager::calculateFixedExpenseForMonth(const QDate& monthStart)
{
    if (!monthStart.isValid()) {
        return 0.0;
    }

    const QDate start(monthStart.year(), monthStart.month(), 1);
    const QDate end = start.addMonths(1).addDays(-1);
    double total = 0.0;

    const QList<AccountRecord> templates = getPeriodicRecords();
    for (const AccountRecord& item : templates) {
        if (item.type != EXPENSE) {
            continue;
        }

        QDate dueDate = item.nextDate.isValid() ? item.nextDate : item.date;
        if (!dueDate.isValid() || item.periodType.trimmed().isEmpty()) {
            continue;
        }

        int guard = 0;
        while (dueDate < start && guard < 5000) {
            dueDate = nextPeriodicDate(dueDate, item.periodType);
            guard++;
        }

        while (dueDate <= end && guard < 5000) {
            total += item.amount;
            dueDate = nextPeriodicDate(dueDate, item.periodType);
            guard++;
        }
    }

    return total;
}

// 读取过去若干个完整月份的日常弹性消费
QList<double> DataManager::getRecentFlexibleMonthlyExpenses(int historyMonths)
{
    QList<double> values;
    if (!ensureDatabase()) {
        return values;
    }

    historyMonths = std::max(1, historyMonths);

    const QDate currentMonth(QDate::currentDate().year(), QDate::currentDate().month(), 1);
    const QDate firstMonth = currentMonth.addMonths(-historyMonths);

    for (int i = 0; i < historyMonths; ++i) {
        const QDate start = firstMonth.addMonths(i);
        const QDate end = start.addMonths(1).addDays(-1);

        QSqlQuery query(db);
        query.prepare("SELECT COALESCE(SUM(r.amount), 0) "
                      "FROM records r "
                      "WHERE r.is_periodic = 0 "
                      "AND r.type = ? "
                      "AND r.date >= ? "
                      "AND r.date <= ? "
                      "AND NOT EXISTS ("
                      "    SELECT 1 FROM records p "
                      "    WHERE p.is_periodic = 1 "
                      "    AND p.type = r.type "
                      "    AND ABS(p.amount - r.amount) < 0.000001 "
                      "    AND IFNULL(p.category, '') = IFNULL(r.category, '') "
                      "    AND IFNULL(p.remark, '') = IFNULL(r.remark, '')"
                      ")");
        query.addBindValue(static_cast<int>(EXPENSE));
        query.addBindValue(start.toString(Qt::ISODate));
        query.addBindValue(end.toString(Qt::ISODate));

        if (query.exec() && query.next()) {
            values.append(query.value(0).toDouble());
        } else {
            values.append(0.0);
        }
    }

    return values;
}

// 计算弹性消费异常值阈值
double DataManager::calculateOutlierThreshold(const QList<double>& values) const
{
    if (values.isEmpty()) {
        return 0.0;
    }

    QList<double> sorted = values;
    std::sort(sorted.begin(), sorted.end());

    auto medianOf = [](const QList<double>& nums) -> double {
        if (nums.isEmpty()) {
            return 0.0;
        }

        const int mid = nums.size() / 2;
        if (nums.size() % 2 == 1) {
            return nums[mid];
        }
        return (nums[mid - 1] + nums[mid]) / 2.0;
    };

    const double median = medianOf(sorted);
    QList<double> deviations;
    for (double value : values) {
        deviations.append(std::fabs(value - median));
    }
    std::sort(deviations.begin(), deviations.end());

    const double mad = medianOf(deviations);
    if (mad <= 0.000001) {
        return sorted.last();
    }

    return median + 3.0 * 1.4826 * mad;
}

// 对清洗后的月度弹性消费做指数权重移动平均
double DataManager::calculateEWMA(const QList<double>& values, double alpha) const
{
    if (values.isEmpty()) {
        return 0.0;
    }

    alpha = std::max(0.01, std::min(alpha, 1.0));

    double forecast = values.first();
    for (int i = 1; i < values.size(); ++i) {
        forecast = alpha * values[i] + (1.0 - alpha) * forecast;
    }

    return forecast;
}

// 保存最近一次预测结果到数据库缓存
bool DataManager::saveExpensePrediction(const ExpensePredictionResult& result)
{
    if (!ensureDatabase()) return false;
    QSqlQuery query(db);
    query.prepare("UPDATE ai_prediction_cache SET "
                  "target_month = ?, current_month_expense = ?, predicted_remaining = ?, "
                  "total_prediction = ?, monthly_limit = ?, exceed_budget = ?, history_months = ?, "
                  "alpha = ?, outlier_threshold = ?, used_month_count = ?, removed_outlier_count = ?, "
                  "updated_at = ?, message = ? WHERE id = 1");
    query.addBindValue(result.targetMonth.toString("yyyy-MM"));
    query.addBindValue(result.currentMonthExpense);
    query.addBindValue(result.predictedRemaining);
    query.addBindValue(result.totalPrediction);
    query.addBindValue(result.monthlyLimit);
    query.addBindValue(result.exceedBudget ? 1 : 0);
    query.addBindValue(result.historyMonths);
    query.addBindValue(result.alpha);
    query.addBindValue(result.outlierThreshold);
    query.addBindValue(result.usedMonthCount);
    query.addBindValue(result.removedOutlierCount);
    query.addBindValue(result.updatedAtDate.toString(Qt::ISODate));
    query.addBindValue(result.message);
    return query.exec();
}

ExpensePredictionResult DataManager::predictionFromQuery(const QSqlQuery& query) const
{
    ExpensePredictionResult result;
    result.targetMonth = QDate::fromString(query.value(0).toString() + "-01", Qt::ISODate);
    result.currentMonthExpense = query.value(1).toDouble();
    result.predictedRemaining = query.value(2).toDouble();
    result.totalPrediction = query.value(3).toDouble();
    result.monthlyLimit = query.value(4).toDouble();
    result.exceedBudget = query.value(5).toInt() != 0;
    result.historyMonths = query.value(6).toInt();
    result.alpha = query.value(7).toDouble();
    result.outlierThreshold = query.value(8).toDouble();
    result.usedMonthCount = query.value(9).toInt();
    result.removedOutlierCount = query.value(10).toInt();
    result.updatedAtDate = QDate::fromString(query.value(11).toString(), Qt::ISODate);
    result.message = query.value(12).toString();
    return result;
}

// 计算指定月份中确定会发生的周期性固定收入
double DataManager::calculateFixedIncomeForMonth(const QDate& monthStart)
{
    if (!monthStart.isValid()) { return 0.0; }

    const QDate start(monthStart.year(), monthStart.month(), 1);
    const QDate end = start.addMonths(1).addDays(-1);
    double total = 0.0;

    const QList<AccountRecord> templates = getPeriodicRecords();
    for (const AccountRecord& item : templates) {
        if (item.type != INCOME) {
            continue;
        }

        QDate dueDate = item.nextDate.isValid() ? item.nextDate : item.date;
        if (!dueDate.isValid() || item.periodType.trimmed().isEmpty()) {
            continue;
        }

        int guard = 0;
        while (dueDate < start && guard < 5000) {
            dueDate = nextPeriodicDate(dueDate, item.periodType);
            guard++;
        }

        while (dueDate <= end && guard < 5000) {
            total += item.amount;
            dueDate = nextPeriodicDate(dueDate, item.periodType);
            guard++;
        }
    }
    return total;
}

// 读取过去若干个完整月份的日常弹性收入
QList<double> DataManager::getRecentFlexibleMonthlyIncomes(int historyMonths)
{
    QList<double> values;
    if (!ensureDatabase()) { return values; }

    historyMonths = std::max(1, historyMonths);
    const QDate currentMonth(QDate::currentDate().year(), QDate::currentDate().month(), 1);
    const QDate firstMonth = currentMonth.addMonths(-historyMonths);

    for (int i = 0; i < historyMonths; ++i) {
        const QDate start = firstMonth.addMonths(i);
        const QDate end = start.addMonths(1).addDays(-1);

        QSqlQuery query(db);
        query.prepare("SELECT COALESCE(SUM(r.amount), 0) FROM records r "
                      "WHERE r.is_periodic = 0 AND r.type = ? AND r.date >= ? AND r.date <= ? "
                      "AND NOT EXISTS ("
                      "    SELECT 1 FROM records p WHERE p.is_periodic = 1 AND p.type = r.type "
                      "    AND ABS(p.amount - r.amount) < 0.000001 "
                      "    AND IFNULL(p.category, '') = IFNULL(r.category, '') "
                      "    AND IFNULL(p.remark, '') = IFNULL(r.remark, '')"
                      ")");
        query.addBindValue(static_cast<int>(INCOME));
        query.addBindValue(start.toString(Qt::ISODate));
        query.addBindValue(end.toString(Qt::ISODate));

        if (query.exec() && query.next()) {
            values.append(query.value(0).toDouble());
        } else {
            values.append(0.0);
        }
    }
    return values;
}

// 统计当前整个账本池内真实发生的累计净可支配余额
double DataManager::getCurrentSavingsBalance()
{
    if (!ensureDatabase()) return 0.0;
    QSqlQuery query(db);
    query.prepare("SELECT COALESCE(SUM(CASE WHEN type = ? THEN amount ELSE -amount END), 0) "
                  "FROM records WHERE is_periodic = 0");
    query.addBindValue(static_cast<int>(INCOME));
    if (query.exec() && query.next()) {
        return query.value(0).toDouble();
    }
    return 0.0;
}

// 储蓄达成推演
SavingsPredictionResult DataManager::updateAISavingsPrediction(int historyMonths, double alpha)
{
    SavingsPredictionResult result;
    if (!ensureDatabase()) return result;

    const QDate today = QDate::currentDate();
    result.targetMonth = QDate(today.year(), today.month(), 1);

    double limit = 0.0;
    getBudget(limit, result.savingsGoal);

    result.currentMonthNetSavings = getTotalIncome(today.year(), today.month()) - getTotalExpense(today.year(), today.month());

    double fixedIncome = calculateFixedIncomeForMonth(result.targetMonth);
    const QList<double> rawInc = getRecentFlexibleMonthlyIncomes(historyMonths);
    double incThreshold = calculateOutlierThreshold(rawInc);
    QList<double> cleanedInc;
    for (double v : rawInc) { if (incThreshold <= 0 || v <= incThreshold) cleanedInc.append(v); }
    double expectedMonthlyIncome = fixedIncome + calculateEWMA(cleanedInc, alpha);

    double fixedExpense = calculateFixedExpenseForMonth(result.targetMonth);
    const QList<double> rawExp = getRecentFlexibleMonthlyExpenses(historyMonths);
    double expThreshold = calculateOutlierThreshold(rawExp);
    QList<double> cleanedExp;
    for (double v : rawExp) { if (expThreshold <= 0 || v <= expThreshold) cleanedExp.append(v); }
    double expectedMonthlyExpense = fixedExpense + calculateEWMA(cleanedExp, alpha);

    int daysInMonth = today.daysInMonth();
    int remainingDays = daysInMonth - today.day();
    result.dailyNetSavingsRate = (expectedMonthlyIncome - expectedMonthlyExpense) / daysInMonth;

    result.updatedAtDate = today;

    if (result.savingsGoal <= 0) {
        result.isAchievable = true; result.estimatedAchieveDate = today;
        result.message = "您暂未设定本月的储蓄目标。";
    } else if (result.currentMonthNetSavings >= result.savingsGoal) {
        result.isAchievable = true; result.estimatedAchieveDate = today;
        result.message = "恭喜！您已提前达成设定的本月储蓄总目标！";
    } else {
        result.isAchievable = false;
        double simulatedNet = result.currentMonthNetSavings;

        for (int d = 1; d <= remainingDays; ++d) {
            simulatedNet += result.dailyNetSavingsRate;
            if (simulatedNet >= result.savingsGoal) {
                result.isAchievable = true;
                result.estimatedAchieveDate = today.addDays(d);
                break;
            }
        }

        if (result.isAchievable) {
            result.message = QString("按当前资金状况与历史规律，预计将在本月 %1 日前后突破目标，正式达成储蓄！")
                                 .arg(result.estimatedAchieveDate.day());
        } else {
            double finalPredictedNet = result.currentMonthNetSavings + (result.dailyNetSavingsRate * remainingDays);
            double finalGap = result.savingsGoal - finalPredictedNet;
            if (result.dailyNetSavingsRate <= 0) {
                result.message = "警告：模型预估您的日均净收益为负，月底不仅无法达成储蓄，反而可能亏损。";
            } else {
                result.message = QString("遗憾：本月时间不足，按当前节律，预计月底仍有约 %1 元的目标缺口。").arg(finalGap, 0, 'f', 2);
            }
        }
    }

    saveSavingsPrediction(result);
    return result;
}

// 读取缓存接口
SavingsPredictionResult DataManager::getAISavingsPrediction()
{
    SavingsPredictionResult result;
    if (!ensureDatabase()) return result;

    QSqlQuery query(db);
    if (query.exec("SELECT target_month, current_month_net_savings, savings_goal, predicted_income, "
                   "predicted_expense, daily_net_savings_rate, is_achievable, estimated_achieve_date, "
                   "history_months, alpha, income_outlier_threshold, used_month_count, "
                   "removed_outlier_count, updated_at, message "
                   "FROM ai_savings_prediction_cache WHERE id = 1")
        && query.next()) {
        result = savingsPredictionFromQuery(query);
        if (result.targetMonth.isValid()) {
            return result;
        }
    }
    return updateAISavingsPrediction();
}

bool DataManager::saveSavingsPrediction(const SavingsPredictionResult& result)
{
    if (!ensureDatabase()) return false;

    QSqlQuery query(db);
    query.prepare("UPDATE ai_savings_prediction_cache SET "
                  "target_month = ?, current_month_net_savings = ?, savings_goal = ?, "
                  "predicted_income = ?, predicted_expense = ?, daily_net_savings_rate = ?, "
                  "is_achievable = ?, estimated_achieve_date = ?, "
                  "history_months = ?, alpha = ?, income_outlier_threshold = ?, "
                  "used_month_count = ?, removed_outlier_count = ?, updated_at = ?, message = ? "
                  "WHERE id = 1");

    query.addBindValue(result.targetMonth.toString("yyyy-MM"));
    query.addBindValue(result.currentMonthNetSavings);
    query.addBindValue(result.savingsGoal);
    query.addBindValue(result.predictedIncome);
    query.addBindValue(result.predictedExpense);
    query.addBindValue(result.dailyNetSavingsRate);
    query.addBindValue(result.isAchievable ? 1 : 0);
    query.addBindValue(result.estimatedAchieveDate.isValid() ? result.estimatedAchieveDate.toString(Qt::ISODate) : "");
    query.addBindValue(result.historyMonths);
    query.addBindValue(result.alpha);
    query.addBindValue(result.incomeOutlierThreshold);
    query.addBindValue(result.usedMonthCount);
    query.addBindValue(result.removedOutlierCount);
    query.addBindValue(result.updatedAtDate.toString(Qt::ISODate));
    query.addBindValue(result.message);

    return query.exec();
}

SavingsPredictionResult DataManager::savingsPredictionFromQuery(const QSqlQuery& query) const
{
    SavingsPredictionResult result;
    result.targetMonth = QDate::fromString(query.value(0).toString() + "-01", Qt::ISODate);
    result.currentMonthNetSavings = query.value(1).toDouble();
    result.savingsGoal = query.value(2).toDouble();
    result.predictedIncome = query.value(3).toDouble();
    result.predictedExpense = query.value(4).toDouble();
    result.dailyNetSavingsRate = query.value(5).toDouble();
    result.isAchievable = query.value(6).toInt() != 0;

    QString rawDate = query.value(7).toString();
    result.estimatedAchieveDate = rawDate.isEmpty() ? QDate() : QDate::fromString(rawDate, Qt::ISODate);

    result.historyMonths = query.value(8).toInt();
    result.alpha = query.value(9).toDouble();
    result.incomeOutlierThreshold = query.value(10).toDouble();
    result.usedMonthCount = query.value(11).toInt();
    result.removedOutlierCount = query.value(12).toInt();
    result.updatedAtDate = QDate::fromString(query.value(13).toString(), Qt::ISODate);
    result.message = query.value(14).toString();
    return result;
}
// CSV 字段转义
QString DataManager::csvEscape(const QString& value) const
{
    QString escaped = value;
    escaped.replace("\"", "\"\"");
    if (escaped.contains(',') || escaped.contains('\n') || escaped.contains('"')) {
        escaped = "\"" + escaped + "\"";
    }
    return escaped;
}

void DataManager::recognizeReceiptImage(const QString& imagePath)
{
    ImageRecognitionResult errorResult;

    QFile file(imagePath);
    if (!file.open(QIODevice::ReadOnly)) {
        errorResult.success = false;
        errorResult.errorMessage = "无法打开选定的图片文件。";
        emit recognitionFinished(errorResult);
        return;
    }
    QByteArray imageData = file.readAll();
    QString base64Image = imageData.toBase64();
    file.close();

    ApiConfig config = getApiConfig();
    QString apiUrl = config.apiUrl;
    QString apiKey = config.apiKey;

    QNetworkRequest request;
    request.setUrl(QUrl(apiUrl));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", QString("Bearer %1").arg(apiKey).toUtf8());

    QJsonObject jsonRequestBody;
    jsonRequestBody["model"] = config.model;

    request.setUrl(QUrl(apiUrl));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", QString("Bearer %1").arg(apiKey).toUtf8());

    jsonRequestBody["model"] = "qwen-vl-plus";

    QJsonArray messages;
    QJsonObject userMessage;
    userMessage["role"] = "user";

    QJsonArray contentArray;

    QJsonObject textContent;
    textContent["type"] = "text";
    textContent["text"] = "你是一个精确的记账账单OCR识别助手。请分析这张图片，提取其中的消费或收入信息，"
                          "并严格以 JSON 格式返回，不要包含任何 Markdown 标记（如 ```json）或多余解释。格式必须如下：\n"
                          "{\n"
                          "  \"amount\": 123.45,\n"
                          "  \"type\": \"EXPENSE\",\n"
                          "  \"category\": \"餐饮支出\",\n"
                          "  \"date\": \"2026-06-04\",\n"
                          "  \"remark\": \"商户名字或消费具体内容\"\n"
                          "}\n"
                          "注意：\n"
                          "1. type 字段只能是 'EXPENSE'(代表支出) 或 'INCOME'(代表收入)。\n"
                          "2. category 字段请根据商户特征智能归类为具体的中文名称（如：餐饮支出、交通出行、日常购物、运动健身、薪资收入等）。\n"
                          "3. date 格式必须为 YYYY-MM-DD，若无法识别请给当天日期。";
    contentArray.append(textContent);

    QJsonObject imageContent;
    imageContent["type"] = "image_url";
    QJsonObject imageUrlObj;
    imageUrlObj["url"] = QString("data:image/jpeg;base64,%1").arg(base64Image); // 拼接前缀
    imageContent["image_url"] = imageUrlObj;
    contentArray.append(imageContent);

    userMessage["content"] = contentArray;
    messages.append(userMessage);
    jsonRequestBody["messages"] = messages;

    QJsonDocument doc(jsonRequestBody);
    QByteArray postData = doc.toJson();

    QNetworkReply* reply = networkManager->post(request, postData);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        ImageRecognitionResult result;
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            result.success = false;
            result.errorMessage = "Qwen API 请求失败: " + reply->errorString();
            emit recognitionFinished(result);
            return;
        }

        QByteArray responseData = reply->readAll();
        QJsonParseError parseError;
        QJsonDocument responseDoc = QJsonDocument::fromJson(responseData, &parseError);

        if (parseError.error != QJsonParseError::NoError) {
            result.success = false;
            result.errorMessage = "API 返回的响应解析 JSON 失败。";
            emit recognitionFinished(result);
            return;
        }

        QJsonObject rootObj = responseDoc.object();
        if (rootObj.contains("choices")) {
            QJsonArray choices = rootObj["choices"].toArray();
            if (!choices.isEmpty()) {
                QJsonObject firstChoice = choices.at(0).toObject();
                QJsonObject messageObj = firstChoice["message"].toObject();
                QString aiContent = messageObj["content"].toString().trimmed();

                if (aiContent.startsWith("```json")) {
                    aiContent = aiContent.mid(7);
                } else if (aiContent.startsWith("```")) {
                    aiContent = aiContent.mid(3);
                }
                if (aiContent.endsWith("```")) {
                    aiContent = aiContent.left(aiContent.length() - 3);
                }
                aiContent = aiContent.trimmed();

                QJsonParseError innerError;
                QJsonDocument innerDoc = QJsonDocument::fromJson(aiContent.toUtf8(), &innerError);

                if (innerError.error == QJsonParseError::NoError) {
                    QJsonObject dataObj = innerDoc.object();

                    result.success = true;
                    result.amount = dataObj["amount"].toDouble();
                    result.remark = dataObj["remark"].toString();
                    result.category = dataObj["category"].toString();

                    QString typeStr = dataObj["type"].toString().toUpper();
                    result.type = (typeStr == "INCOME") ? INCOME : EXPENSE;

                    result.date = QDate::fromString(dataObj["date"].toString(), "yyyy-MM-dd");
                    if (!result.date.isValid()) {
                        result.date = QDate::currentDate();
                    }
                } else {
                    result.success = false;
                    result.errorMessage = "大模型未按规定格式返回JSON，原始答复为:\n" + aiContent;
                }
            }
        } else {
            result.success = false;
            result.errorMessage = "API 未包含合法的 choices 节点，可能触发了敏感词或账户欠费。";
        }

        emit recognitionFinished(result);
    });
}

void DataManager::recognizeReceiptWithAi(const QString& userPrompt,
                                         const QImage& image,
                                         const QStringList& allowedCategories,
                                         DataManager::AiCallback callback)
{
    qDebug() << "[AI] ===============================================";
    qDebug() << "[AI] 收到智能识别请求。";
    bool hasImage = !image.isNull();
    bool hasText = !userPrompt.trimmed().isEmpty();

    if (!hasImage && !hasText) {
        callback(false, AccountRecord(), "未检测到有效输入！请输入记账文字或拖入账单图片。");
        return;
    }

    QString base64Image;
    if (hasImage) {
        QByteArray byteArray;
        QBuffer buffer(&byteArray);
        buffer.open(QIODevice::WriteOnly);
        image.save(&buffer, "JPG", 85);
        base64Image = byteArray.toBase64();
        buffer.close();
        qDebug() << "[AI] 模式：[多模态图片+文本识别]";
    } else {
        qDebug() << "[AI] 模式：[纯文本对话记账]";
    }

    ApiConfig config = getApiConfig();
    QString apiUrl = config.apiUrl;
    QString apiKey = config.apiKey;

    QNetworkRequest request;
    request.setUrl(QUrl(apiUrl));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", QString("Bearer %1").arg(apiKey).toUtf8());

    QString todayStr = QDate::currentDate().toString("yyyy-MM-dd");

    QString finalPrompt;
    if (hasImage) {
        finalPrompt = "你是一个精密的记账单据/发票/收据 OCR 智能识别引擎。请帮我分析这张账单图片。\n";
    } else {
        finalPrompt = "你是一个精密的纯文本记账智能解析引擎。请帮我分析用户输入的记账文本陈述。\n";
    }

    finalPrompt += QString(
                       "\n【🚨 核心时间基准 🚨】\n"
                       "当前的现实世界真实日期今天是：%1\n"
                       "注意：如果用户在文字或单据中提到了“昨天”、“前天”、“上周五”、“大前天”等相对时间词汇，"
                       "你必须以这个【当前现实世界真实日期】为绝对基准，进行日期的加减推导计算！\n"
                       "（例如：今天是 2026-06-05，用户说“昨天”，则 JSON 中的 date 必须精准计算并填入 \"2026-06-04\"）。\n\n"
                       ).arg(todayStr);

    finalPrompt += QString(
                       "你必须严格返回一个合法的纯 JSON 格式字符串，绝对不能包含任何 markdown 的 ```json 包裹标记，也不要包含任何多余的解释文字。\n\n"
                       "JSON 的格式规范必须严格如下：\n"
                       "{\n"
                       "  \"amount\": 123.45,  // 数值类型，识别到的实际消费/收入总金额\n"
                       "  \"type\": \"EXPENSE\", // 字符串类型，只能是 \"EXPENSE\"（支出）或 \"INCOME\"（收入）\n"
                       "  \"category\": \"分类名\", // 字符串类型，必须从允许的分类列表中选择\n"
                       "  \"date\": \"%1\", // 字符串类型，格式统一为 yyyy-MM-dd\n"
                       "  \"remark\": \"商户名或简短商品说明\"\n"
                       "}\n"
                       ).arg(todayStr);

    if (hasText) {
        finalPrompt += "\n用户的输入内容/额外补充说明：" + userPrompt;
    }

    if (!allowedCategories.isEmpty()) {
        finalPrompt += "\n\n【❗ 核心分类约束 ❗】\n"
                       "请注意：你的 JSON 中 'category' 字段的值必须且只能从以下合法列表中选择，绝不允许自定义：\n"
                       + allowedCategories.join("、")
                       + "\n如果内容无法明确对应，请一律分类为 '其他'。";
    }
    QJsonObject jsonRequestBody;
    jsonRequestBody["model"] = config.model;

    QJsonArray messages;
    QJsonObject userMessage;
    userMessage["role"] = "user";
    QJsonArray contentArray;

    QJsonObject textContent;
    textContent["type"] = "text";
    textContent["text"] = finalPrompt;
    contentArray.append(textContent);

    if (hasImage) {
        QJsonObject imageContent;
        imageContent["type"] = "image_url";
        QJsonObject imageUrlObj;
        imageUrlObj["url"] = QString("data:image/jpeg;base64,%1").arg(base64Image);
        imageContent["image_url"] = imageUrlObj;
        contentArray.append(imageContent);
    }

    userMessage["content"] = contentArray;
    messages.append(userMessage);
    jsonRequestBody["messages"] = messages;

    QJsonDocument doc(jsonRequestBody);
    QByteArray requestData = doc.toJson();

    QNetworkReply* reply = networkManager->post(request, requestData);
    connect(reply, &QNetworkReply::finished, this, [reply, callback]() {
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            callback(false, AccountRecord(), "网络请求失败: " + reply->errorString());
            return;
        }

        QByteArray responseData = reply->readAll();
        QJsonDocument jsonResponse = QJsonDocument::fromJson(responseData);
        if (jsonResponse.isNull()) {
            callback(false, AccountRecord(), "服务器返回的响应不是有效的 JSON 格式。");
            return;
        }

        QJsonObject jsonObj = jsonResponse.object();
        if (!jsonObj.contains("choices")) {
            callback(false, AccountRecord(), "API 响应缺少 'choices' 节点。");
            return;
        }

        QJsonArray choices = jsonObj["choices"].toArray();
        if (choices.isEmpty()) {
            callback(false, AccountRecord(), "API 返回的 choices 列表为空。");
            return;
        }

        QJsonObject firstChoice = choices.at(0).toObject();
        QJsonObject messageObj = firstChoice["message"].toObject();
        QString aiContent = messageObj["content"].toString().trimmed();

        // 清洗大模型附带的冗余 markdown 标记
        if (aiContent.startsWith("```json", Qt::CaseInsensitive)) {
            aiContent = aiContent.mid(7);
        } else if (aiContent.startsWith("```")) {
            aiContent = aiContent.mid(3);
        }
        if (aiContent.endsWith("```")) {
            aiContent = aiContent.left(aiContent.length() - 3);
        }
        aiContent = aiContent.trimmed();

        QJsonDocument innerDoc = QJsonDocument::fromJson(aiContent.toUtf8());
        if (!innerDoc.isNull() && innerDoc.isObject()) {
            QJsonObject dataObj = innerDoc.object();
            AccountRecord record;
            // 解析金额
            QJsonValue amountVal = dataObj["amount"];
            if (amountVal.isString()) {
                record.amount = amountVal.toString().toDouble();
            } else {
                record.amount = amountVal.toDouble();
            }
            // 解析备注与分类
            record.remark = dataObj["remark"].toString().trimmed();
            record.category = dataObj["category"].toString().trimmed();
            // 解析收支类型
            QString typeStr = dataObj["type"].toString().toUpper().trimmed();
            record.type = (typeStr == "INCOME") ? INCOME : EXPENSE;
            // 解析并矫正日期
            QString dateStr = dataObj["date"].toString().trimmed();
            record.date = QDate::fromString(dateStr, "yyyy-MM-dd");
            if (!record.date.isValid()) {
                record.date = QDate::currentDate();
            }

            qDebug() << "[AI] 解析结果成功发布! 最终金额:" << record.amount
                     << " 分类:" << record.category;

            callback(true, record, "");
        } else {
            callback(false, AccountRecord(), "AI未能生成合法的JSON对象数据，答复原始内容为:\n" + aiContent);
        }
    });
}

// 生成加密密钥
QByteArray DataManager::getEncryptionKey() const
{
    QString salt = "YourFixedSalt_ChangeMe!@#";
    QString machineId = QSysInfo::machineUniqueId();
    QString combined = salt + machineId;
    return QCryptographicHash::hash(combined.toUtf8(), QCryptographicHash::Sha256);
}

// XOR + Base64 加密
QString DataManager::encryptString(const QString& plain) const
{
    QByteArray key = getEncryptionKey();
    QByteArray data = plain.toUtf8();
    for (int i = 0; i < data.size(); ++i) {
        data[i] = data[i] ^ key[i % key.size()];
    }
    return data.toBase64();
}

QString DataManager::decryptString(const QString& encrypted) const
{
    QByteArray data = QByteArray::fromBase64(encrypted.toUtf8());
    QByteArray key = getEncryptionKey();
    for (int i = 0; i < data.size(); ++i) {
        data[i] = data[i] ^ key[i % key.size()];
    }
    return QString::fromUtf8(data);
}

// 获取配置
ApiConfig DataManager::getApiConfig() const
{
    QMutexLocker locker(&configMutex);
    QSettings settings("YourCompany", "AccountBook");
    ApiConfig config;
    config.apiUrl = settings.value("Api/Url", "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions").toString();
    QString encryptedKey = settings.value("Api/Key").toString();
    if (!encryptedKey.isEmpty()) {
        config.apiKey = decryptString(encryptedKey);
    }
    config.model = settings.value("Api/Model", "qwen-vl-plus").toString();
    return config;
}

// 保存配置
bool DataManager::setApiConfig(const ApiConfig& config)
{
    QMutexLocker locker(&configMutex);
    QSettings settings("YourCompany", "AccountBook");
    settings.setValue("Api/Url", config.apiUrl);
    settings.setValue("Api/Key", encryptString(config.apiKey));
    settings.setValue("Api/Model", config.model);
    return true;
}

bool DataManager::hasApiConfig() const
{
    QSettings settings("YourCompany", "AccountBook");
    return settings.contains("Api/Key") && !settings.value("Api/Key").toString().isEmpty();
}

void DataManager::clearApiConfig()
{
    QMutexLocker locker(&configMutex);
    QSettings settings("YourCompany", "AccountBook");

    settings.remove("Api");
    qDebug() << "[AI] 本地加密 API 配置已彻底清除。";
}