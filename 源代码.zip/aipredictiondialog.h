#ifndef AIPREDICTIONDIALOG_H
#define AIPREDICTIONDIALOG_H

#include <QDialog>

namespace Ui {
class AiPredictionDialog;
}

class AiPredictionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AiPredictionDialog(QWidget *parent = nullptr);
    ~AiPredictionDialog();
    void loadAIReport();

private:
    Ui::AiPredictionDialog *ui;
};

#endif // AIPREDICTIONDIALOG_H
